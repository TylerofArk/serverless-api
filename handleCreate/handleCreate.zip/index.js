'use strict';

const dynamoose = require('dynamoose')

const peopleSchema = new dynamoose.Schema({
	id: String,
	name: String,
	phone: String,
});

const peopleModel = dynamoose.model('people', peopleSchema);
console.log('EVENT BODY', event.body)

let { id, name, phone} = event.queryStringParameters;

let friend ={id, name, phone};

console.log('THIS IS A CONSOLE LOG -----', friend);
    
exports.handler = async (event) => {
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from handleCreate'),
    };
    return response;
};
